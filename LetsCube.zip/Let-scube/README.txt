--- project name: LBar ---
--- Owner: Petrovskiy A.A. ---
--- Date of connecting to github: 02.10.21 ---

Instruments: Java, FireBase, MaterialDesign

Functionality:
- Search speedcubers all over the world
- Chat with everyone you want and add them to friends
- Look & share news and records
- Make cubing rooms and compete with your friends
- Keep cubes collection statistics

[Android | minSdkVersion : 26]